var searchData=
[
  ['finalize',['finalize',['../structSCOREP__Metric__Plugin__Info.html#a47c7086fff6e72e3ca197d483aba2502',1,'SCOREP_Metric_Plugin_Info::finalize()'],['../structSCOREP__SubstratePluginInfo.html#adbadbf92e832b5e59808fea790632382',1,'SCOREP_SubstratePluginInfo::finalize()']]]
];
