var searchData=
[
  ['scorep_5fmetric_5fplugin_5finfo',['SCOREP_Metric_Plugin_Info',['../structSCOREP__Metric__Plugin__Info.html',1,'']]],
  ['scorep_5fmetric_5fplugin_5fmetricproperties',['SCOREP_Metric_Plugin_MetricProperties',['../structSCOREP__Metric__Plugin__MetricProperties.html',1,'']]],
  ['scorep_5fmetric_5fproperties',['SCOREP_Metric_Properties',['../structSCOREP__Metric__Properties.html',1,'']]],
  ['scorep_5fmetrictimevaluepair',['SCOREP_MetricTimeValuePair',['../structSCOREP__MetricTimeValuePair.html',1,'']]],
  ['scorep_5fsubstrateplugincallbacks',['SCOREP_SubstratePluginCallbacks',['../structSCOREP__SubstratePluginCallbacks.html',1,'']]],
  ['scorep_5fsubstrateplugininfo',['SCOREP_SubstratePluginInfo',['../structSCOREP__SubstratePluginInfo.html',1,'']]]
];
