var indexSectionsWithContent =
{
  0: "bcefilmop",
  1: "op",
  2: "op",
  3: "cfp",
  4: "m",
  5: "o",
  6: "p",
  7: "c",
  8: "bceilop"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros",
  8: "Pages"
};

